import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './compornents/App';
import './scss/index.scss';
import { BrowserRouter} from "react-router-dom";

import { configureStore } from '@reduxjs/toolkit';
import { Provider } from 'react-redux';
import postsReducer from "./compornents/features/Posts";


const store = configureStore({
  reducer:{
    posts:postsReducer,
  }
});


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
    <Provider store={store}>
      <App />
    </Provider>
  </BrowserRouter>
);
