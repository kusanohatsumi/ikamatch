import React from 'react'

export const FirstView = () => {
  return (
    <div className='firstView'>
        <div className='firstView__item'>
            <h1>Logo</h1>
            <p>text</p>
        </div>
        <div className='firstView__item'>
            <figure><img /></figure>
            <p>text</p>
        </div>
    </div>
)
}
