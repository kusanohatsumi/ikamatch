import React from 'react'

export const About = () => {
  return (
    <div>
        <p>イカマッチについて</p>
    </div>
  )
}
