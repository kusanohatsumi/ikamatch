const Option = [
  { id: 1,  name:"エリアを選択する",  value: "no_img.jpg" },
  { id: 2,  name:"ユノハナ大渓谷",  value: "yunohana.jpg" },
  { id: 3,  name:"ゴンズイ地区",  value: "gonnzui.jpg" },
  { id: 4,  name:"ヤガラ市場",  value: "yagara.jpg" },
  { id: 5,  name:"マテガイ放水路",  value: "mategai.jpg" },
  { id: 6,  name:"ナメロウ金属",  value: "namerou.jpg" },
  { id: 7,  name:"マサバ海峡大橋",  value: "masaba.jpg" },
  { id: 8,  name:"キンメダイ美術館",  value: "kinnmedai.jpg" },
  { id: 9,  name:"マヒマヒリゾート&スパ",  value: "mahimahi.jpg" },
  { id: 10, name:"海女美術大学",  value: "ama.jpg" },
  { id: 11, name:"チョウザメ造船",  value: "tyouzame.jpg" },
  { id: 12, name:"ザトウマーケット",  value: "zatou.jpg" },
  { id: 13, name:"スメーシーワールド&スパ",  value: "sume-shi-.jpg" },
  { id: 14, name:"ヒラメが丘団地",  value: "hirame.jpg" },
]

export default Option;
