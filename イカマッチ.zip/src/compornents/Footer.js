import React from 'react'

export const Footer = () => {
  return (
    <footer>
        <ul>
            <li></li>
        </ul>
    </footer>
  )
}

export default Footer;
